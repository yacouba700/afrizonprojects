import 'package:flutter/material.dart';

class AddonConfig{
  static bool club_point_addon_installed = false;
  static bool refund_addon_installed = false;
  static bool otp_addon_installed = false;

}